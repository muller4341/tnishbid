const prisma = require('../prismaClient');
const { uploadImage, uploadMultipleImages, optimizeCloudinaryUrl } = require('../utils/cloudinary');
const cache = require('../utils/cache');
const { parseExactTimestamp } = require('../utils/dateHelper');
const { settleItem, settleExpiredAuctions } = require('../utils/settlement');

const invalidateItemCache = (id) => {
  cache.del('items:all');
  if (id != null) {
    cache.del(`item:${id}`);
    const num = parseInt(id, 10);
    if (!isNaN(num)) {
      cache.del(`item:${num}`);
    }
  }
};
exports.invalidateItemCache = invalidateItemCache;

// Anchors date strings so the exact wall-clock timestamp is preserved in PostgreSQL
const parseToEAT = parseExactTimestamp;

exports.getItems = async (req, res) => {
  try {
    const cached = cache.get('items:all');
    if (cached) {
      res.setHeader('X-Cache', 'HIT');
      res.setHeader('Cache-Control', 'public, max-age=5, stale-while-revalidate=20');
      return res.json(cached);
    }

    await settleExpiredAuctions(req.io);
    const items = await prisma.item.findMany({
      orderBy: { created_at: 'desc' },
      include: {
        _count: {
          select: { bids: true }
        }
      }
    });

    const optimizedItems = items.map((item) => ({
      ...item,
      is_lub: item.pool_type === 'lub' || item.pool_type === 'premium',
      image_url: optimizeCloudinaryUrl(item.image_url),
      images: Array.isArray(item.images) ? item.images.map(optimizeCloudinaryUrl) : item.images
    }));

    cache.set('items:all', optimizedItems, 30);
    res.setHeader('X-Cache', 'MISS');
    res.setHeader('Cache-Control', 'public, max-age=5, stale-while-revalidate=20');
    res.json(optimizedItems);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getItemById = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const cacheKey = `item:${id}`;
    const cached = cache.get(cacheKey);
    if (cached) {
      res.setHeader('X-Cache', 'HIT');
      res.setHeader('Cache-Control', 'public, max-age=3, stale-while-revalidate=10');
      return res.json(cached);
    }

    const item = await prisma.item.findUnique({
      where: { id },
      include: {
        winner: {
          select: { id: true, name: true, phone_number: true }
        },
        _count: {
          select: { bids: true }
        },
        bids: {
          include: {
            user: {
              select: { id: true, name: true, phone_number: true }
            }
          },
          orderBy: { created_at: 'desc' }
        }
      }
    });
    if (!item) return res.status(404).json({ error: 'Item not found' });

    const optimizedItem = {
      ...item,
      is_lub: item.pool_type === 'lub' || item.pool_type === 'premium',
      image_url: optimizeCloudinaryUrl(item.image_url),
      images: Array.isArray(item.images) ? item.images.map(optimizeCloudinaryUrl) : item.images
    };

    cache.set(cacheKey, optimizedItem, 15);
    res.setHeader('X-Cache', 'MISS');
    res.setHeader('Cache-Control', 'public, max-age=3, stale-while-revalidate=10');
    res.json(optimizedItem);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createItem = async (req, res) => {
  try {
    const { title, description, category, pool_type, is_lub, base_price, start_time, end_time, images } = req.body;
    let image_url = '';
    let itemImages = [];

    if (Array.isArray(images)) {
      itemImages = images;
    } else if (typeof images === 'string') {
      try {
        itemImages = JSON.parse(images);
      } catch {
        itemImages = images.split(',').map(s => s.trim()).filter(Boolean);
      }
    }

    if (req.files && Array.isArray(req.files) && req.files.length > 0) {
      const uploadedUrls = await uploadMultipleImages(req.files, { folder: 'tinishbid/items' });
      const validUrls = uploadedUrls.filter(Boolean);
      if (validUrls.length > 0) {
        image_url = validUrls[0];
        itemImages = [...itemImages, ...validUrls];
      }
    } else if (req.file) {
      const uploadedUrl = await uploadImage(req.file, { folder: 'tinishbid/items' });
      if (uploadedUrl) {
        image_url = uploadedUrl;
        itemImages = [...itemImages, uploadedUrl];
      }
    }

    // Also upload any base64 images passed in the body
    if (itemImages.length > 0) {
      itemImages = (await uploadMultipleImages(itemImages, { folder: 'tinishbid/items' })).filter(Boolean);
    }

    if (!image_url && itemImages.length > 0) {
      image_url = itemImages[0];
    }

    const isLubBool = is_lub === true || is_lub === 'true' || pool_type === 'lub' || pool_type === 'premium';

    const item = await prisma.item.create({
      data: {
        title,
        description,
        category: category || 'Electronics',

        pool_type: isLubBool ? 'lub' : 'open',
        image_url,
        images: itemImages,
        base_price: parseFloat(base_price),
        start_time: parseToEAT(start_time),
        end_time: parseToEAT(end_time),
        status: 'active'
      }
    });
    invalidateItemCache();

    // Broadcast new bid post event & notify users who enabled "New Bid Post" (bidDrops)
    if (req.io) {
      req.io.emit('new_bid_post', {
        item_id: item.id,
        title: item.title,
        category: item.category,
        image_url: item.image_url,
        base_price: item.base_price,
        message: `New Bid Post: "${item.title}" is now open for bidding!`
      });
    }

    try {
      const { getUserPreferences } = require('../utils/preferenceStore');
      const allUsers = await prisma.user.findMany({ select: { id: true } });
      const notifData = allUsers
        .filter(u => getUserPreferences(u.id).bidDrops !== false)
        .map(u => ({
          user_id: u.id,
          message: `New Bid Post: "${item.title}" is now open for bidding!`,
          notification_type: 'bid'
        }));

      if (notifData.length > 0) {
        await prisma.notification.createMany({ data: notifData });
      }
    } catch (notifErr) {
      console.warn('Failed to dispatch new bid post notifications:', notifErr.message);
    }

    res.status(201).json(item);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateItem = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { title, description, category, pool_type, is_lub, base_price, start_time, end_time, status, images, existing_images } = req.body;
    
    const existing = await prisma.item.findUnique({ where: { id } });
    if (!existing) return res.status(404).json({ error: 'Item not found' });

    // 1. Determine retained existing images
    let itemImages = [];
    const rawImagesPayload = existing_images !== undefined ? existing_images : images;

    if (rawImagesPayload !== undefined) {
      if (Array.isArray(rawImagesPayload)) {
        itemImages = rawImagesPayload.filter(img => typeof img === 'string' && img.trim() !== '');
      } else if (typeof rawImagesPayload === 'string') {
        try {
          const parsed = JSON.parse(rawImagesPayload);
          if (Array.isArray(parsed)) {
            itemImages = parsed.filter(img => typeof img === 'string' && img.trim() !== '');
          } else if (typeof parsed === 'string' && parsed.trim() !== '') {
            itemImages = [parsed.trim()];
          }
        } catch {
          itemImages = rawImagesPayload.split(',').map(s => s.trim()).filter(Boolean);
        }
      }
    } else if (existing.images && Array.isArray(existing.images) && existing.images.length > 0) {
      itemImages = [...existing.images];
    } else if (existing.image_url) {
      itemImages = [existing.image_url];
    }

    // 2. Upload and append any new files from req.files or req.file
    if (req.files && Array.isArray(req.files) && req.files.length > 0) {
      const uploadedUrls = await uploadMultipleImages(req.files, { folder: 'tinishbid/items', prefix: `item_${id}` });
      const validUrls = uploadedUrls.filter(Boolean);
      if (validUrls.length > 0) {
        itemImages = [...itemImages, ...validUrls];
      }
    } else if (req.file) {
      const uploadedUrl = await uploadImage(req.file, { folder: 'tinishbid/items', prefix: `item_${id}` });
      if (uploadedUrl) {
        itemImages = [...itemImages, uploadedUrl];
      }
    }

    // 3. Process any base64 images if passed
    if (itemImages.length > 0) {
      itemImages = (await uploadMultipleImages(itemImages, { folder: 'tinishbid/items' })).filter(Boolean);
    }

    // 4. Primary cover photo is strictly the first image
    const primaryImageUrl = itemImages.length > 0 ? itemImages[0] : null;

    const isLubBool = is_lub !== undefined 
      ? (is_lub === true || is_lub === 'true')
      : (pool_type !== undefined ? (pool_type === 'lub' || pool_type === 'premium') : existing.is_lub);

    const updated = await prisma.item.update({
      where: { id },
      data: {
        title: title !== undefined ? title : existing.title,
        description: description !== undefined ? description : existing.description,
        category: category !== undefined ? category : existing.category,
        pool_type: isLubBool ? 'lub' : 'open',
        base_price: base_price !== undefined ? parseFloat(base_price) : existing.base_price,
        start_time: start_time ? parseToEAT(start_time) : existing.start_time,
        end_time: end_time ? parseToEAT(end_time) : existing.end_time,
        status: status !== undefined ? status : existing.status,
        image_url: primaryImageUrl,
        images: itemImages
      }
    });

    invalidateItemCache(id);

    if ((status === 'ended' || status === 'closed') && existing.status === 'active') {
      try {
        await settleItem(id, req.io);
      } catch (settleErr) {
        console.warn('Manual end auction settlement error:', settleErr.message);
      }
    }

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.migrateImagesToDisk = async (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const UPLOADS_DIR = path.resolve(__dirname, '../../uploads');
    const ITEMS_DIR = path.join(UPLOADS_DIR, 'items');
    const AVATARS_DIR = path.join(UPLOADS_DIR, 'avatars');

    [UPLOADS_DIR, ITEMS_DIR, AVATARS_DIR].forEach((dir) => {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    });

    const items = await prisma.item.findMany();
    let updatedCount = 0;
    let bytesSaved = 0;

    for (const item of items) {
      let updated = false;
      let newImageUrl = item.image_url;
      let newImages = Array.isArray(item.images) ? [...item.images] : [];

      if (item.image_url && item.image_url.startsWith('data:')) {
        const match = item.image_url.match(/^data:([A-Za-z0-9-+/]+);base64,(.+)$/);
        if (match) {
          const ext = match[1].includes('png') ? '.png' : (match[1].includes('webp') ? '.webp' : '.jpg');
          const fname = `item_${item.id}_main_${Date.now()}${ext}`;
          const buf = Buffer.from(match[2], 'base64');
          fs.writeFileSync(path.join(ITEMS_DIR, fname), buf);
          newImageUrl = `/uploads/items/${fname}`;
          bytesSaved += buf.length;
          updated = true;
        }
      }

      if (Array.isArray(item.images)) {
        for (let i = 0; i < item.images.length; i++) {
          const img = item.images[i];
          if (img && typeof img === 'string' && img.startsWith('data:')) {
            const match = img.match(/^data:([A-Za-z0-9-+/]+);base64,(.+)$/);
            if (match) {
              const ext = match[1].includes('png') ? '.png' : (match[1].includes('webp') ? '.webp' : '.jpg');
              const fname = `item_${item.id}_gal_${i}_${Date.now()}${ext}`;
              const buf = Buffer.from(match[2], 'base64');
              fs.writeFileSync(path.join(ITEMS_DIR, fname), buf);
              newImages[i] = `/uploads/items/${fname}`;
              bytesSaved += buf.length;
              updated = true;
            }
          }
        }
      }

      if (updated) {
        await prisma.item.update({
          where: { id: item.id },
          data: { image_url: newImageUrl, images: newImages }
        });
        updatedCount++;
      }
    }

    const { syncUploadsToPublicHtml } = require('../utils/cloudinary');
    const syncedCount = syncUploadsToPublicHtml();

    invalidateItemCache();
    res.json({
      success: true,
      updated_items: updatedCount,
      mb_saved: (bytesSaved / (1024 * 1024)).toFixed(2),
      synced_to_public_html: syncedCount,
      items_summary: items.map(it => ({ id: it.id, title: it.title, image_url: it.image_url }))
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteItem = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    const existing = await prisma.item.findUnique({ where: { id } });
    if (!existing) return res.status(404).json({ error: 'Item not found' });

    // Delete dependent bids first
    await prisma.bid.deleteMany({ where: { item_id: id } });
    await prisma.item.delete({ where: { id } });

    invalidateItemCache(id);
    res.json({ message: 'Item deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
